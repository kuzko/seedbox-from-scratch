Release Notes  -  SABnzbd 0.7.18
================================

## Features

- Support for X-Failure header (leading to an alternative NZB)
- Support for detecting unwanted extensions inside RAR files
- Using priority Force will override duplicate detection
- Add "pause_pp" and "server_stats" to the API

## Bug fixes
- Also remove colons ":" with option sanitize_safe
- Notification: Respect NotifyOSD-preference and allow testing of values from UI
- Prevent pseudo error message when testing "Notification Center"
- Testing email based on values in UI instead of stored config
- Don't trim file names when renaming them (so revert to old behavior)
- Fix potential crash when unpacking due to unset variable
- Pause/abort on encryption failed when pre-check was active
- Allow "embedded" passwords in job titles again

## What's new in 0.7.0

- Download quota management
- Windows: simple system tray menu
- Multi-platform Growl support
- NotifyOSD support for Linux distros that have it
- Option to set maximum number of retries for servers (prevents deadlock)
- Pre-download check to estimate completeness (reliability is limited)
- Prevent partial downloading of par2 files that are not needed yet
- Config->Special for settings previously only available in the sabnzbd.ini file
- For Usenet servers with multiple IP addresses, pick a random one per connection
- Add pseudo-priority "Stop" that will send the job immediately to the post-processing queue
- Allow jobs still  waiting for post-processing to be deleted too
- More persistent retries for unreliable indexers
- Single Configuration skin for all others skins (there is an option for the old style)
- Config->Special for settings that were previously only changeable in the sabnzbd.ini file
- Add Spanish, Portuguese (Brazil) and Polish translations
- Individual RSS filter toggle
- Unified OSX DMG


## About
  SABnzbd is an open-source cross-platform binary newsreader.
  It simplifies the process of downloading from Usenet dramatically,
  thanks to its web-based user interface and advanced
  built-in post-processing options that automatically verify, repair,
  extract and clean up posts downloaded from Usenet.

  (c) Copyright 2007-2013 by "The SABnzbd-team" \<team@sabnzbd.org\>


### IMPORTANT INFORMATION about release 0.7.x
<http://wiki.sabnzbd.org/introducing-0-7-0>

### Known problems and solutions
- Read the file "ISSUES.txt"

### Upgrading from 0.6.x
- Stop SABnzbd
- Install new version
- Start SABnzbd

### Upgrading from 0.5.x
- Stop SABnzbd
- Install new version
- Start SABnzbd.

The organization of the download queue is different from 0.5.x.
0.7.x will finish downloading an existing queue, but you
cannot go back to an older version without losing your queue.
Also, your sabnzbd.ini file will be upgraded, making it
incompatible with release 0.5.x

### Upgrading from 0.4.x
Download your current queue before upgrading.
